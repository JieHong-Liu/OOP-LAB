#include "Document.h"

// ======================
// Assignment operator
// simply copy the string for the text.
// ======================
Document& Document::operator =(const Document& rightSide)
{
	// Simply copy the string for the text value
	this->text = rightSide.text;
	return *this;
}
