﻿#include <iostream>
#include <string>
#include <vector>

using namespace std;

string SymptomDeny[] = { "Fever", "Dry cough", "Fatigue", "Shortness of breath", "Chills" };
string RegionDeny[] = { "China", "USA", "Italy", "Spain", "Germany", "Iran", "France", "UK", "Switzerland" };
const int SymptomsDenyLength = 5;
const int RegionsDenyLength = 9;

class Log
{
public:
	Log() {}
	Log(string ID, string Phy, string His, bool Access = false)
	{
		this->ID = ID;
		this->PhyCondition = Phy;
		this->TravelHistory = His;
		this->Access = Access;
	}

	static bool CheckAccess(string Phy, string His);
	static Log Create(string ID, string Phy, string His);

	string ID;
	string PhyCondition;
	string TravelHistory;
	bool Access;
};

class Logger
{
public:
	void Add();
	void List();
private:
	vector<Log> logs;
};

int main()
{
	string cmd;
	Logger logger;

	while (cin >> cmd)
	{
		if (cmd == "Access") logger.Add();
		else if (cmd == "List") logger.List();
	}

	return 0;
}

bool Log::CheckAccess(string Phy, string His)
{
	for (int i = 0; i < SymptomsDenyLength; i++)
	{
		if (SymptomDeny[i].find(Phy) != string::npos) return false;
	}

	for (int i = 0; i < RegionsDenyLength; i++)
	{
		if (RegionDeny[i].find(His) != string::npos) return false;
	}

	return true;
}

Log Log::Create(string ID, string Phy, string His)
{
	bool access = CheckAccess(Phy, His);
	return Log(ID, Phy, His, access);
}

void Logger::Add()
{
	char buffer[50];
	string tmp;

	string id;
	string phy;
	string his;

	cin >> id;

	cin.getline(buffer, 50);

	tmp = string(buffer);
	size_t space_idx = tmp.find_last_of(' ');

	for (int space_idx = tmp.length() - 1; space_idx >= 0; space_idx--)
	{
		if (tmp[space_idx] == ' ') break;
	}

	phy = tmp.substr(1, space_idx - 1);
	his = tmp.substr(space_idx + 1);

	auto log = Log::Create(id, phy, his);
	logs.push_back(log);


	cout << id << " ";
	if (log.Access) {
		cout << "Access allowed." << endl;
	}
	else
	{
		cout << "Access denied." << endl;
	}
}

void Logger::List()
{
	for (auto& log : logs) {
		cout << log.ID << "\t" << log.PhyCondition << "\t" << log.TravelHistory << "\t" << (log.Access ? "Allowed" : "Denied") << endl;
	}
}