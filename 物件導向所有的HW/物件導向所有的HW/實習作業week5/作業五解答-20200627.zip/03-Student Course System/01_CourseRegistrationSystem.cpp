// Project : Course Registration System
// Create : Pin-Shao Chen
// Date : 20200223
// E-mail : fansen7@gmail.com

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <sstream>

#define STU_NOT_EXIST "The student's name does not exist."
#define COURSE_NOT_EXIST "The course does not exist."
#define STU_NAME_EXIST "The student's name is duplicate."
#define COURSE_CONFLICT "Course conflict."
#define STU_LIST_EMPTY "The Students list is empty."

using namespace std;

class Schedule
{
public:
	Schedule() { // 5 * 10
		table.resize(5);
		for (auto& x : table)
			x.resize(11);
	}
	~Schedule() { table.clear(); }
	inline vector<vector<string>>& getTable() { return table; }
private:
	vector<vector<string>> table;
};
class CRS
{
public:
	CRS();
	~CRS();
	void AddStudent(string);
	void AddCourse(string, string, vector<string>);
	void DelStudent(string);
	void DelCourse(string, string);
	void StudentList();
	void Print(string);
	void Print(string, string);
	bool searchStudent(string);
	vector<string> searchCourse(string, string);
private:
	vector<string> Students;
	map<string, Schedule> schedules_table;
	string week[5] = { "M", "T", "W", "R", "F" };

};

CRS::CRS()
{
}

CRS::~CRS()
{
	Students.clear();
	schedules_table.clear();
}
void CRS::AddStudent(string Student_name) {
	if (searchStudent(Student_name))
	{
		cout << STU_NAME_EXIST << endl;
		return;
	}
	else
	{
		Schedule schedule;
		Students.push_back(Student_name);
		schedules_table.insert({ Student_name, schedule });
	}
}
void CRS::AddCourse(string Student_name, string Course_name, vector<string> class_vec) {
	if (!searchStudent(Student_name))
	{
		cout << STU_NOT_EXIST << endl;
		return;
	}
	else {
		Schedule& schedule = schedules_table[Student_name];
		for (auto& x : class_vec) { // Is Course conflict?
			string day = x.substr(0, 1);
			int time = stoi(x.substr(1, x.size() - 1));
			for (int i = 0; i < 5; ++i) {
				if (day == week[i]) {
					if (schedule.getTable()[i][time] != "") {
						cout << COURSE_CONFLICT << endl;
						return;
					}
				}
			}
		}
		for (auto& x : class_vec) { // Add Course
			string day = x.substr(0, 1);
			int time = stoi(x.substr(1, x.size() - 1));
			for (int i = 0; i < 5; ++i) {
				if (day == week[i]) {
					schedule.getTable()[i][time] = Course_name;
				}
			}

		}
	}
}
void CRS::DelStudent(string Student_name) {
	if (!searchStudent(Student_name))
	{
		cout << STU_NOT_EXIST << endl;
		return;
	}
	else
	{
		for (int i = 0; i < Students.size(); i++) {
			if (Students[i] == Student_name) {
				Students.erase(Students.begin() + i);
				break;
			}
		}
		schedules_table.erase(Student_name);

	}
}
void CRS::DelCourse(string Student_name, string Course_name) {

	if (!searchStudent(Student_name))
	{
		cout << STU_NOT_EXIST << endl;
		return;
	}
	else if (searchCourse(Student_name, Course_name).empty()) {
		cout << COURSE_NOT_EXIST << endl;
		return;
	}
	else {
		vector<string> class_vec = searchCourse(Student_name, Course_name);
		vector<vector<string>>& table = schedules_table[Student_name].getTable();
		for (auto& x : class_vec) {
			string day = x.substr(0, 1);
			int time = stoi(x.substr(1, x.size() - 1));
			for (int i = 0; i < 5; ++i) {
				if (day == week[i]) {
					table[i][time] = "";
				}
			}
		}
	}

}
bool CRS::searchStudent(string Student_name) {
	for (int i = 0; i < Students.size(); ++i) {
		if (Students[i] == Student_name)
			return true;
	}
	return false;
}
vector<string> CRS::searchCourse(string Student_name, string Course_name) {
	vector<vector<string>> table = schedules_table[Student_name].getTable();
	vector<string> timeTable;
	for (int i = 0; i < table.size(); ++i)
		for (int j = 0; j < table[i].size(); ++j) {
			if (table[i][j] == Course_name) {
				string time = week[i] + to_string(j);
				timeTable.push_back(time);
			}
		}
	return timeTable;
}
void CRS::StudentList() {
	if (Students.empty()) {
		cout << STU_LIST_EMPTY << endl;
		return;
	}
	for (auto& x : Students) {
		cout << x << endl;
	}
	return;
}
void CRS::Print(string Student_name) {
	if (!searchStudent(Student_name))
	{
		cout << STU_NOT_EXIST << endl;
		return;
	}
	else {
		vector<vector<string>> table = schedules_table[Student_name].getTable();
		for (int i = 0; i < table.size(); i++)
		{
			cout << week[i] << ":";
			for (int j = 0; j < table[i].size(); ++j) {
				if(table[i][j] != "")
					cout << " " << j << ":" << table[i][j];
			}
			cout << endl;
		}
	}
}
void CRS::Print(string Student_name, string Course_name) {
	if (!searchStudent(Student_name))
	{
		cout << STU_NOT_EXIST << endl;
		return;
	}
	else if (searchCourse(Student_name, Course_name).empty()) {
		cout << COURSE_NOT_EXIST << endl;
		return;
	}
	else {
		vector<string> class_vec = searchCourse(Student_name, Course_name);
		cout << Course_name;
		for (auto& x : class_vec) {
			cout << " " << x;
		}
		cout << endl;
	}
}

int main() {
	string cmd = "";
	string Student_name = "";
	string Course_name = "";
	string class_str = "";
	CRS crs;

	while (cin >> cmd)
	{
		if (cmd == "AddStudent") {
			cin >> Student_name;
			crs.AddStudent(Student_name);
		}
		else if (cmd == "AddCourse") {
			stringstream ss;
			cin >> Student_name >> Course_name;
			getline(cin, class_str);
			ss << class_str;
			vector<string> class_vec;
			while (ss >> class_str)
				class_vec.push_back(class_str);

			crs.AddCourse(Student_name, Course_name, class_vec);
		}
		else if (cmd == "DelStudent") {
			cin >> Student_name;
			crs.DelStudent(Student_name);
		}
		else if (cmd == "DelCourse") {
			cin >> Student_name >> Course_name;
			crs.DelCourse(Student_name, Course_name);
		}
		else if (cmd == "Print") {

			stringstream ss;
			vector<string> cmd_vec;

			getline(cin, cmd);
			ss << cmd;

			while (ss >> cmd)
				cmd_vec.push_back(cmd);

			if (cmd_vec.size() == 1) {
				if (cmd_vec[0] == "StudentList") {
					crs.StudentList();
				}
				else {
					crs.Print(cmd_vec[0]);
				}
			}
			else if (cmd_vec.size() == 2) {
				crs.Print(cmd_vec[0], cmd_vec[1]);
			}
		}
	}
	return 0;
}