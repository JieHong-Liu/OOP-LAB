#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Student
{
private:
	string name;
	int score;
	int grade[4] = { 90,80,70,60 };
	string gradeText[5] = { "A+", "A", "B", "C", "F" };
public:
	Student()
	{
		name = "";
		score = 0;
	}
	Student(string name, int score)
	{
		this->name = name;
		this->score = score;
	}
	string getName() { return name; }
	void setName(string name) { this->name = name; }
	int getMath() { return score; }
	void setMath(int score) { this->score = score; }

	string calcGrade() 
	{
		for (int i = 0; i < 4; i = i + 1)
		{
			if (score >= grade[i]) return gradeText[i];
		}
		return gradeText[4];
	}
};

class Manager 
{
private:
	vector<Student> list;
	int find(string name)
	{
		for (int i = 0; i < list.size(); i = i + 1)
		{
			if (list[i].getName() == name)
			{
				return i;
			}
		}
		return -1;
	}
public:
	bool insert(Student student)
	{
		int index = find(student.getName());
		if (index != -1) return false;

		list.push_back(student);
		return true;
	}
	int search(string name) 
	{
		int index = find(name);
		if (index != -1) return list[index].getMath();
		return -1;
	}
	vector<string> search(int value) 
	{
		vector<string> match;
		for (int i = 0; i < list.size(); i = i + 1)
		{
			if (list[i].getMath() > value) match.push_back(list[i].getName());
		}
		return match;
	}
	bool update(string name, int value) 
	{
		int index = find(name);
		if (index != -1)
		{
			list[index].setMath(value);
			return true;
		}
		return false;
	}
	bool update(string name, string newName)
	{
		int index = find(name);
		if (index != -1)
		{
			list[index].setName(newName);
			return true;
		}
		return false;
	}
	bool del(string name) 
	{
		int index = find(name);
		if (index != -1)
		{
			list.erase(list.begin() + index);
			return true;
		}
		return false;
	}
	string score(string name) 
	{
		int index = find(name);
		if (index != -1)
		{
			return list[index].calcGrade();
		}
		return "N";
	}
	void showList() 
	{
		for (int i = 0; i < list.size(); i = i + 1)
		{
			cout << list[i].getName() << ", " << list[i].getMath() << endl;
		}
	}
};

int main()
{
	Manager system;
	string cmd;
	while (cin >> cmd)
	{
		if (cmd == "insert")
		{
			string name;
			int score;
			cin >> name >> score;
			Student temp(name, score);
			bool result = system.insert(temp);
			if (result) { cout << "insert success with name " << name << endl; }
			else { cout << "insert fail with " << name << "!!!" << endl; }
		}
		else if (cmd == "search")
		{
			string value;
			cin >> value;
			if (value[0] >= '0' && value[0] <= '9') //value mode
			{
				int newValue = stoi(value);
				vector<string> result = system.search(newValue);
				if (result.size() != 0)
				{
					for (int i = 0; i < result.size(); i = i + 1)
					{
						cout << result[i] << endl;
					}
				}
				else cout << "no one match the condition" << endl;
			}
			else
			{
				int result = system.search(value);
				if (result != -1) cout << value << " score is " << result << endl;
				else cout << value << " is not in system!!!" << endl;
			}
		}
		else if (cmd == "update")
		{
			string name;
			string value;
			cin >> name >> value;
			if (value[0] >= '0' && value[0] <= '9') //value mode
			{
				int newValue = stoi(value);
				bool result = system.update(name, newValue);
				if (result) cout << "update value success" << endl;
				else cout << name << " is not in system!!!" << endl;
			}
			else
			{
				bool result = system.update(name, value);
				if (result) cout << "update name success" << endl;
				else cout << name << " is not in system!!!" << endl;
			}
		}
		else if (cmd == "delete")
		{
			string name;
			cin >> name;
			bool result = system.del(name);
			if (result) cout << "remove " << name << endl;
			else cout << name << " is not in system!!!" << endl;
		}	
		else if (cmd == "score")
		{
			string name;
			cin >> name;
			string result = system.score(name);
			if (result != "N") cout << "grade: " << result << endl;
			else cout << name << " is not in system!!!" << endl;
		}
		else if (cmd == "show")
		{
			system.showList();
		}

	}
	return 0;
}