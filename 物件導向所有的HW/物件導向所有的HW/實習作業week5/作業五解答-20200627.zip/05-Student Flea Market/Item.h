#ifndef Item_H 
#define Item_H 

class Item {
public:
	int id = -1;
	int value = 0;

	Item(void);
	Item(int id, int value);
};


#endif // Item_H 
