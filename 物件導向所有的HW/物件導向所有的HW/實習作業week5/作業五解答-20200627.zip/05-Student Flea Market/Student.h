#ifndef PLAYER_H 
#define PLAYER_H 

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>
#include "Item.h"

using namespace std;

class Student {
public:
	Student(int id, int money, vector<Item> item) : id(id), money(money), ItemList(item) { }

	void trade(Student& student, int ItemId, int min, int max);
	void buy(Item buyItem);
	void sell(Item sellItem);
	void show(void);

private:
	int id;
	int money;
	vector<Item> ItemList;

	Item find(int ItemId, int min, int max);
	int find(Item& find_Item);
	bool checkMoney(int price);
};

#endif // PLAYER_H 