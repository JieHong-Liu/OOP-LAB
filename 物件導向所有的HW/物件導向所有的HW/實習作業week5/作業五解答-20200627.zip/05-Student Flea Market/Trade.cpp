//Project : Trade
//Create : Hong-Yang Shih
//Date : 20200120
//E-mail : M10815005@mail.ntust.edu.tw 
#include "Student.h"

#include <iostream>
#include <string>
#include <vector>

int main(void)
{
	vector<Item> shop;
	vector<Student> students;
	int numCustomers, numItem, value;
	cin >> numCustomers >> numItem;
	for (int i = 0; i < numCustomers; ++i)
	{
		cin >> value;
		students.push_back(Student(i, value, vector<Item>()));
	}
	for (int i = 0; i < numItem; ++i)
	{
		cin >> value;
		shop.push_back(Item(i, value));
	}

	string operation;
	int studentId, studentId2, itemId, itemValue;
	while (cin >> operation)
	{
		try {
			if (operation == "buy")
			{
				cin >> studentId >> itemId;
				students[studentId].buy(shop[itemId]);
			}
			else if (operation == "sell")
			{
				cin >> studentId >> itemId >> itemValue;
				students[studentId].sell(Item(itemId, itemValue));
			}
			else if (operation == "trade")
			{
				int min, max;
				cin >> studentId >> studentId2 >> itemId >> min >> max;
				students[studentId].trade(students[studentId2], itemId, min, max);
			}
			else if (operation == "show")
			{
				cin >> studentId;
				students[studentId].show();
			}
			else if (operation == "end")
				break;
		}
		catch (string str)	{
			cout << str << endl;
		}
		catch (exception & e) {	
			cout << e.what() << endl;
		}
	}
	return 0;
}





