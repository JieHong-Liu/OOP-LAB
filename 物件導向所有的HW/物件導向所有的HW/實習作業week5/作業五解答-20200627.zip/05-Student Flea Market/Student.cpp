# include "Student.h"

bool compare_f(Item a, Item b) { return a.id < b.id || (a.id == b.id && a.value < b.value); }
void Student::trade(Student& student, int ItemId, int min, int max)
{
	Item buyItem = student.find(ItemId, min, max);
	if (this->checkMoney(buyItem.value))
		throw "Student " + to_string(this->id) + " doesn't have enough money.";
	student.sell(buyItem);
	this->buy(buyItem);
}
void Student::buy(Item buyItem)
{
	if (this->checkMoney(buyItem.value))
		throw "Student " + to_string(this->id) + " doesn't have enough money.";

	this->money -= buyItem.value;
	buyItem.value = buyItem.value - 10 > 0 ? buyItem.value - 10 : 0;
	ItemList.push_back(buyItem);
}
void Student::sell(Item sellItem)
{
	int index = this->find(sellItem);
	if (index < 0)
		throw "Student " + to_string(this->id) + " doesn't have this item.";

	this->money += sellItem.value;
	this->ItemList.erase(this->ItemList.begin() + index);
}
void Student::show(void)
{
	sort(this->ItemList.begin(), this->ItemList.end(), &compare_f);

	cout << "Student " << this->id << " has $" << this->money << "." << endl;
	for (auto it = this->ItemList.begin(); it != this->ItemList.end(); it++)
		cout << "ID " << (*it).id << " $" << (*it).value << endl;
}
Item Student::find(int ItemId, int min, int max)
{
	Item result = Item(ItemId, -1);
	for (auto it = this->ItemList.begin(); it != this->ItemList.end(); it++)
		if (((*it).id == ItemId && (*it).value >= min && (*it).value <= max && (*it).value > result.value))
			result = *it;
	return result;
}
int Student::find(Item& find_Item)
{
	int index = -1;
	for (auto it = this->ItemList.begin(); it != this->ItemList.end(); it++)
		if ((*it).id == find_Item.id && (*it).value == find_Item.value)
		{
			index = it - this->ItemList.begin();
			break;
		}
	return index;
}
bool Student::checkMoney(int price)
{
	return money < price;
}

