#include "Item.h"


Item::Item(void) {}
Item::Item(int id, int value) : id(id), value(value) 
{
}
