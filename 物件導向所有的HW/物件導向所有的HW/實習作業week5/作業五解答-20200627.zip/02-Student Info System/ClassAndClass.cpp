﻿#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class Student 
{
public:
    string ID;
    string Name;
    string Gender;
    float Height;
    float Weight;

    void Show() const;
};

class StudentDatabase
{
public:
    void Add();
    void Del();
    void Edit();
    void Find();
    void List();

    void Add(string id, string name, string gender, float height, float weight);
    void Del(string id);
    Student* Find(string id);
    bool Exist(string id);
private:
    vector<Student> students;
};

bool Compare(Student& a, Student& b) {
    return a.ID < b.ID;
}

int main()
{
    StudentDatabase db;
    string command;
    while (cin >> command)
    {
        if (command == "Add") db.Add();
        else if (command == "Del") db.Del();
        else if (command == "Edit") db.Edit();
        else if (command == "Find") db.Find();
        else if (command == "List") db.List();
    }
}

void StudentDatabase::Add()
{
    string id;
    string name;
    string gender;
    float height;
    float weight;

    cin >> id >> name >> gender >> height >> weight;
    Add(id, name, gender, height, weight);
}

void StudentDatabase::Del()
{
    string id;
    cin >> id;

    Del(id);
}

void StudentDatabase::Edit()
{
    string id;
    string var;
    cin >> id >> var;

    string str;
    float number = 0.0F;

    if (var == "Name" || var == "Gender") {
        cin >> str;
    }
    else if (var == "Height" || var == "Weight") {
        cin >> number;
    }

    Student* student = Find(id);

    if (student == nullptr)
    {
        cout << "Student Not Found." << endl;
        return;
    }
    else 
    {
        if (var == "Name") {
            student->Name = str;
        }
        else if (var == "Gender") {
            student->Gender = str;
        }
        else if (var == "Height") {
            student->Height = number;
        }
        else if (var == "Weight") {
            student->Weight = number;
        }
    }
}

void StudentDatabase::Find()
{
    string id;
    cin >> id;

    Student* student = Find(id);
    if (student != nullptr) {
        student->Show();
    }else cout << "Student Not Found." << endl;
}

void StudentDatabase::List()
{
    sort(students.begin(), students.end(), Compare);
    for (auto& student : students)
    {
        student.Show();
    }
}

void StudentDatabase::Add(string id, string name, string gender, float height, float weight)
{
    if (Exist(id))
    {
        cout << "The student's ID is duplicate." << endl;
        return;
    }

    Student std;
    std.ID = id;
    std.Name = name;
    std.Gender = gender;
    std.Height = height;
    std.Weight = weight;

    students.push_back(std);
}

void StudentDatabase::Del(string id)
{
    if (!Exist(id))
    {
        cout << "Student Not Found." << endl;
        return;
    }

    for (auto it = students.begin(); it != students.end(); it++)
    {
        if (it->ID == id)
        {
            students.erase(it);
            return;
        }
    }
}

Student* StudentDatabase::Find(string id)
{
    for (auto& student : students)
    {
        if (student.ID == id)
        {
            return &student;
        }
    }
    return nullptr;
}

bool StudentDatabase::Exist(string id)
{
    return Find(id) != nullptr;
}

void Student::Show() const
{
    cout << ID << '\t' << Name << '\t' << Gender << '\t' << Height << '\t' << Weight << endl;
}
