#pragma once
#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <vector>
#include <iterator>
using namespace std;
class NumberGame {
private:
	int input;
	vector<int> valids;
	string fileName;
	vector<int> numbers;
public:
	void SetInput(int i) { input = i; };
	void ProcessInput() { 
		vector<int> digits;
		for (; input; input /= 10) digits.push_back(input % 10);
		for (int i = 1; i < 1 << digits.size(); i++) {
			int valid = 1;
			for (int j = 0; j < digits.size(); j++) if (i & (1 << j)) valid *= digits[j];
			valids.push_back(valid);
		}
		sort(valids.begin(), valids.end());
		valids.resize(distance(valids.begin(), unique(valids.begin(), valids.end())));
	}
	void SetFileName(string name) { fileName = name; }
	void LoadNumberList() { 
		fstream fin(fileName);
		copy(istream_iterator<int>(fin), istream_iterator<int>(), back_inserter(numbers));
	}
	void PrintAllValid() {
		for (auto valid : valids) {
			for (auto num : numbers) {
				if (valid == num) cout << valid << endl;
			}
		}
	}
	void Reset() {
		numbers.clear();
		valids.clear();
	}
};