#include "Diary.h"
vector<Diary *>Diary::all;
string Diary::day;
void Diary::NewDay(string day)
{
	Diary::day = day;
	for (auto log : all)
	{
		log->log += "\nDay " + day;
	}
}

Diary::Diary()
{
	all.push_back(this);
	(*this).log = "Day " + day ;
}

void Diary::printLog()
{
	cout << log << endl;
}
