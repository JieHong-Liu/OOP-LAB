#pragma once
#include <string>
#include <vector>
#include <map>
#include "Diary.h"

class Creature
{
public:
	string name;
	Diary diary;
	class Body
	{
	public:
		string name;
		int number;
		Body(Creature *const parent, const string &name, const int number = 0) : parent(parent), name(name), number(number) {};
		Body &operator=(const int number);
		Body &operator+=(const int number);
		Body &operator-=(const int number);
	public:
		Creature *parent;
	};
	vector<Body> body;
public:
	Creature(string name) : name(name) { };
	Creature(string name,Creature);
	void PrintStatus();
	void PrintLog();
	Body &operator[](const string &Name);
};