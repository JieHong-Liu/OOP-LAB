#pragma once
#include <string>
#include <vector>
#include <iostream>
using namespace std;
class Diary
{
public:
	static void NewDay(string day);
	Diary();
	string log;
	static vector<Diary *> all;
	void printLog();
public:
	static string day;

};


