#include "Creature.h"
#include <map>

Creature::Creature(string name, Creature base)
{
	this->name = name;
	for (auto body : base.body)
		this->body.push_back(Body(this, body.name, body.number));
}

void Creature::PrintStatus()
{
	cout << name << "'s status: " << endl;
	map<string, int> s;
	for (auto all : body) {
		s[all.name] = all.number;
	}
	for (auto all : s) {
		if (all.second != 0)
			cout << all.first << " * " << all.second << endl;
	}
	cout << endl;
}

void Creature::PrintLog()
{
	cout << name << "'s log:" << endl;
	diary.printLog();
	cout << endl;
}

Creature::Body & Creature::operator[](const string & Name)
{
	for (auto &all : body) {
		if (all.name == Name) {
			return all;
		}
	}
	body.push_back(Body(this, Name));
	return body.back();
}

Creature::Body & Creature::Body::operator=(const int number)
{
	if (this->number != number) {
		parent->diary.log += "\n";
		if (this->number == 0) {
			parent->diary.log += parent->name + "'s " + name + " appeared (" + to_string(this->number) + " -> " + to_string(number) + ")";
		}
		else if (this->number < number) {
			parent->diary.log += parent->name + "'s " + name + " increased (" + to_string(this->number) + " -> " + to_string(number) + ")";
		}
		else if (number == 0) {
			parent->diary.log += parent->name + "'s " + name + " disappeared (" + to_string(this->number) + " -> " + to_string(number) + ")";
		}
		else if (this->number > number) {
			parent->diary.log += parent->name + "'s " + name + " decreased (" + to_string(this->number) + " -> " + to_string(number) + ")";
		}
		parent->diary.log += ".";
		this->number = number;
	}
	return *this;
}

Creature::Body & Creature::Body::operator+=(const int number)
{
	return this->operator=(this->number + number);
}

Creature::Body & Creature::Body::operator-=(const int number)
{
	return this->operator=(this->number - number);
}

