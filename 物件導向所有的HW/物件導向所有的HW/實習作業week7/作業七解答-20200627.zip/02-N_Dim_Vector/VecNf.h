#pragma once
#include <iostream>
using namespace std;
class VecNf {
private:
	float *_data;
	int _size;
	VecNf(float **dest, int cnt) { _data = *dest; _size = cnt; }
	
public:
	VecNf() { _data = new float[1]; _size = 1; _data[0] = 0.0f; }
	VecNf(float *dest, int cnt) : _size(cnt) { _data = new float[_size]; for (int i = 0; i < _size; i++) _data[i] = dest[i]; }
	~VecNf() {  delete[] _data;}
	VecNf(const VecNf& rhs) {
		_data = new float[_size = rhs._size];
		for (int i = 0; i < _size; i++) _data[i] = rhs._data[i];
	}
	VecNf & operator=(const VecNf& rhs) { 
		cout << "ASSIGNMENT!!!" << endl;
		if (this == &rhs) return *this;
		delete[] _data;
		_data = new float[_size = rhs._size];
		for (int i = 0; i < _size; i++) _data[i] = rhs._data[i];
		return *this;
	}
	VecNf operator+(const VecNf &rhs) {
		if (_size != rhs._size) { cout << "dimensions inconsistent" << endl; return VecNf(); }
		float *dest = new float[_size];
		for (int i = 0; i < _size; i++) dest[i] = _data[i] + rhs._data[i];
		return VecNf(&dest, _size);
	}
	VecNf operator-(const VecNf &rhs) {
		if (_size != rhs._size) { cout << "dimensions inconsistent" << endl; return VecNf(); }
		float *dest = new float[_size];
		for (int i = 0; i < _size; i++) dest[i] = _data[i] - rhs._data[i];
		return VecNf(&dest, _size);
	}
	float operator*(const VecNf &rhs) {
		if (_size != rhs._size) { cout << "dimensions inconsistent" << endl; return 0.0f; }
		float ans = 0.0f;
		for (int i = 0; i < _size; i++) ans += _data[i] * rhs._data[i];
		return ans;
	}
	friend VecNf operator*(float scale, const VecNf &tar) {
		float *dest = new float[tar._size];
		for (int i = 0; i < tar._size; i++) dest[i] = tar._data[i] * scale;
		return VecNf(&dest, tar._size);
	}
	friend VecNf operator*(const VecNf &tar, float scale) {
		float *dest = new float[tar._size];
		for (int i = 0; i < tar._size; i++) dest[i] = tar._data[i] * scale;
		return VecNf(&dest, tar._size);
	}

	float & operator[](int index) {
		return _data[index];
	}
	int Size() { return _size; }
};
