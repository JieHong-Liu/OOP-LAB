#include<stdio.h>
 
int main()
{
    float INCOME, AMOUNT;
    while (scanf("%f", &INCOME) != EOF) {
        if (INCOME < 750.00f)
            AMOUNT = .01f*INCOME;
        else if (INCOME < 2250.00f)
            AMOUNT = 7.50 + .02f*(INCOME - 750.00f);
        else if (INCOME < 3750.00f)
            AMOUNT = 37.50 + .03f*(INCOME - 2250.00f);
        else if (INCOME < 5250.00f)
            AMOUNT = 82.50 + .04f*(INCOME - 3750.00f);
        else if (INCOME < 7000.00f)
            AMOUNT = 142.50 + .05f*(INCOME - 5250.00f);
        else AMOUNT = 230.00 + .06f*(INCOME - 7000.00f);
        printf("%.2f\n", AMOUNT);
    }
 
    return 0;
}