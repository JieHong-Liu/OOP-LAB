#include <iostream>
#include <string>
using namespace std;

struct BigInt
{
	string Dec = {};
};
int main()
{
	int count;
	cin >> count;
	for (int j = 0; j < count; j++)
	{
		int err = 0;
		BigInt a, b;
		cin >> a.Dec;
		cin >> b.Dec;
		for (int i = 0; i < a.Dec.size(); i++)
			if (a.Dec[i]<'0' || a.Dec[i]>'9')
				err = 1;
		for (int i = 0; i < b.Dec.size(); i++)
			if (b.Dec[i]<'0' || b.Dec[i]>'9')
				err = 1;
		if (!err)
		{
			BigInt Summary;
			int leng = a.Dec.size();

			if (b.Dec.size() > leng)
			{
				leng = b.Dec.size();
				a.Dec.insert(0, b.Dec.size() - a.Dec.size(), '0');
			}
			else
				b.Dec.insert(0, a.Dec.size() - b.Dec.size(), '0');

			int carry = 0, i = 0;
			for (i = leng; i >= 0; i--)
			{
				int Total;
				Total = a.Dec[i] - '0' + b.Dec[i] - '0' + carry;
				if (Total >= 10)
				{
					Total -= 10;
					carry = 1;
				}
				else
					carry = 0;

				Summary.Dec.insert(0, 1, Total + '0');
			}
			if (carry)
				Summary.Dec.insert(0, 1, '1');
			Summary.Dec.erase(Summary.Dec.size() - 1);
			cout << Summary.Dec << endl;
		}
		else
			cout << "Not a valid number, please try again." << endl;
	}
	return 0;
}


