#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	int count;
	string *name;
	string *bonus;
	string *salary;
	int nameleng, bonusleng, salaryleng;
	while (cin >> count)
	{
		name = new string[count];
		bonus = new string[count];
		salary = new string[count];
		nameleng = bonusleng = salaryleng = 0;
		for (int i = 0; i < count; i++)
		{
			cin >> name[i];
			cin >> bonus[i];
			cin >> salary[i];
			if (!i) nameleng = name[i].size();
			else
				if (name[i].size() > nameleng)
					nameleng = name[i].size();

			if (!i) bonusleng = bonus[i].size();
			else
				if (bonus[i].size() > bonusleng)
					bonusleng = bonus[i].size();

			if (!i) salaryleng = salary[i].size();
			else
				if (salary[i].size() > salaryleng)
					salaryleng = salary[i].size();
		}
		for (int i = 0; i < count; i++)
		{
			cout.setf(ios::right);
			cout << setw(nameleng) << name[i] << "|  " << setw(bonusleng) << bonus[i] << "|  " << setw(salaryleng) << salary[i] << endl;
		}
	}
	return 0;
}
