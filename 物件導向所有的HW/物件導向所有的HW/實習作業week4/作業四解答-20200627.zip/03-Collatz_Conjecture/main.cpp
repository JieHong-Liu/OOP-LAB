#include <iostream>
using namespace std;

int main() 
{
	unsigned int i, j;
	while (cin >> i >> j) 
	{
		unsigned int n1 = i, n2 = j;
		if (i > j) { int t = i; i = j; j = t; }
		int max = 1;
		for (int x = i; x <= j; x++) 
		{
			int n = x, time = 1;
			while (n > 1) 
			{
				n = n & 1 ? n * 3 + 1 : n / 2;
				time++;
			}
			max = time > max ? time : max;
		}
		cout << n1 << " " << n2 << " " << max << endl;
	}

}