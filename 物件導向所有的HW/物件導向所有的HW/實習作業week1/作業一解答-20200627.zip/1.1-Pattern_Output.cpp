#include <iostream>
using namespace std;
int main()
{
	cout<<"       *"<<endl<<"      *"<<endl<<"     *"<<endl<<"*   *"<<endl<<" * *"<<endl<<"  *";
	return 0;
}
