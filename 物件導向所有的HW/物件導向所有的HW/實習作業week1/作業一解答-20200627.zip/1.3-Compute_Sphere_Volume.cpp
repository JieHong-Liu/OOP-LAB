#include <iostream>
#include <iomanip>

using namespace std;

const double PI = 3.14159265358979323846;

int main() {
	double radius;
	double volume;

	while(cin >> radius) {
		volume = (4.0 / 3.0) * PI * radius * radius * radius;
		cout << fixed << setprecision(6) << volume << endl;
	}
	return 0;	
}