// Project : Row Transposition Cipher
// Create : Pin-Shao Chen
// Date : 20200308
// E-mail : fansen7@gmail.com

#include<iostream>
#include<string>
#include<vector>
#include<sstream>

using namespace std;

string rowTransposition(const vector<int>& key, const string& plainText) {

	vector<string> cipherMatrix;
	string cipherText;
	string plainTextCopy = plainText;

	int pos = plainTextCopy.find(" ", 0);
	while (pos != -1) {
		plainTextCopy.replace(pos, 1 , "_");
		pos = plainTextCopy.find(" ", pos);
	}

	for (int i = 0; i < key.size(); i++) {
		cipherMatrix.push_back(string());
	}
	for (int i = 0; i < plainTextCopy.size(); i++) {
		cipherMatrix[i % key.size()] += plainTextCopy[i];
	}
	for (int i = 0; i < key.size(); i++) {
		cipherText += cipherMatrix[key[i]];
	}
	return cipherText;
}

int main() {
	string plainText = "";
	string keys = "";
	int tmp;
	vector<int> key;
	stringstream ss("");

	while (getline(cin, plainText)) {
		getline(cin, keys);
		ss << keys;
		while (ss >> tmp) {
			key.push_back(tmp);
		}
		cout << rowTransposition(key, plainText) << endl;

		ss.clear();
		ss.str("");
		plainText = "";
		keys = "";
		key.clear();
	}
	return 0;
}