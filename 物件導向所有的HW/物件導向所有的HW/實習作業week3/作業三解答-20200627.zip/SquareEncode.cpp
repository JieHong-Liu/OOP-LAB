#include <iostream>
#include <vector>
#include <string>
#include <cmath>

using namespace std;
#define SQUARE_SIZE 7

int main()
{
	
	string temp;
	while(cin >> temp)
	{
		vector< vector< vector<int> > > blockText;
		for (int j = 0; j < temp.size(); j = j + 1)
		{
			if (j % (SQUARE_SIZE * 2) == 0) //init
			{
				blockText.push_back(vector< vector<int> >());
				for (int k = 0; k < SQUARE_SIZE; k = k + 1)
				{
					blockText[j / (SQUARE_SIZE * 2)].push_back(vector<int>());
					for (int kk = 0; kk < SQUARE_SIZE; kk = kk + 1)
					{
						blockText[j / (SQUARE_SIZE * 2)][k].push_back(0);
					}
				}
			}

			int value = (int)temp[j];
			for (int k = SQUARE_SIZE - 1; k >= 0; k = k - 1)
			{
				int bit = value / pow(2, k);
				if (j % (SQUARE_SIZE * 2) < SQUARE_SIZE) //row
				{
					blockText[blockText.size() - 1][j % (SQUARE_SIZE * 2)][(SQUARE_SIZE - 1) - k] = blockText[blockText.size() - 1][j % (SQUARE_SIZE * 2)][(SQUARE_SIZE - 1) - k] + bit * 2;
				}
				else //column
				{
					blockText[blockText.size() - 1][k][j % (SQUARE_SIZE * 2) - SQUARE_SIZE] = blockText[blockText.size() - 1][k][j % (SQUARE_SIZE * 2) - SQUARE_SIZE] + bit;
				}
				value = value % (int)pow(2, k);
			}
		}
		for (int j = 0; j < blockText.size(); j = j + 1)
		{
			for (int k = SQUARE_SIZE - 1; k >= 0; k = k - 1)
			{
				for (int kk = 0; kk < SQUARE_SIZE; kk = kk + 1)
				{
					cout << blockText[j][k][kk];
				}
				cout << endl;
			}
		}
	}

	return 0;
}