#include <iostream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

int main()
{
	int n;
	while (cin >> n)
	{
		for (int i = 0; i < n; i = i + 1) //n block
		{
			vector<int> partValue;
			for (int i = 0; i < 14; i = i + 1)
			{
				partValue.push_back(0);
			}

			for (int j = 6; j >= 0; j = j - 1)
			{
				string temp;
				cin >> temp;
				for (int k = 6; k >= 0; k = k - 1)
				{
					int value = temp[6 - k] - '0';
					int MSB = value / 2;
					int LSB = value % 2;
					partValue[j] = partValue[j] + MSB * pow(2, k);
					partValue[13 - k] = partValue[13 - k] + LSB * pow(2, j);
				}
			}
			for (int j = 0; j < 14; j = j + 1)
			{
				if (partValue[j] != 0) cout << (char)partValue[j];
			}
		}
		cout << endl;
	}
	
	return 0;
}