// Project : Caesar Cipher
// Create : Pin-Shao Chen
// Date : 20200308
// E-mail : fansen7@gmail.com

#include<iostream>
#include<string>
#include<vector>

using namespace std;

string caesarCipher(const string plainText, const int key) {

	string cipherText = "";
	for (int i = 0; i < plainText.size(); i++) {
		if (plainText[i] == ' ') {
			cipherText += ' ';
			continue;
		}
		cipherText += (plainText[i] - 'a' + key) % 26;
		while (cipherText.back() < 0)
			cipherText.back() += 26;
		cipherText.back() += 'a';
	}
	return cipherText;
}

int main() {
	string plainText = "";
	int key = 0;

	while (getline(cin, plainText)) {
		cin >> key;
		cin.ignore();
		cout << caesarCipher(plainText, key) << endl;
	}
	return 0;
}