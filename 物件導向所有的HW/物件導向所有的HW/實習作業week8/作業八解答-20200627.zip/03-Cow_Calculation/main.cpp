#include <stdio.h>

int toVal(char* s) {
	int N = 0, i;
	for (i = 0; s[i] != 0; i++) {
		N *= 10;
		switch (s[i]) {
		case'V': N += 0; break;
		case'U': N += 1; break;
		case'C': N += 2; break;
		case'D': N += 3; break;
		}
	}
	return N;
}

int main() 
{	
	int T, i, l, Num[3], Ten, Digit, Tmp;
	char buf[10], OP, Val;	
	while (scanf("%d", &T) != EOF)
	{
		int status[10] = {-1};
		int index = 0;		
		while (T--) 
		{
			scanf("%s", buf);
			Num[0] = toVal(buf);
			scanf("%s", buf);
			Num[1] = toVal(buf);
			for (i = 0; i < 3; i++) 
			{
				scanf(" %c", &OP);
				if (OP == 'A') 
				{
					Num[1] += Num[0];
					for (Ten = 1; Num[1] / Ten > 0; Ten *= 10) 
					{
						while ((Tmp = (Num[1] / Ten) % 10) >= 4) 
						{
							Num[1] += 6 * Ten;
						}
					}
				}
				else if (OP == 'R') 
				{
					Num[1] /= 10;
				}
				else if (OP == 'L') 
				{
					Num[1] *= 10;
				}
			}
			scanf("%s", buf);
			Num[2] = toVal(buf);
			status[index] = (Num[2] == Num[1]) ? 1 : 0;
			index++;
		}
		printf("COWCULATIONS OUTPUT\n");
		for (int i = 0; i < index; i++)
		{
			if (status[i] == -1)continue;
			else if (status[i] == 1)printf("YES\n");
			else if (status[i] == 0)printf("NO\n");
		}
		printf("END OF OUTPUT\n");		
	}
	return 0;
}