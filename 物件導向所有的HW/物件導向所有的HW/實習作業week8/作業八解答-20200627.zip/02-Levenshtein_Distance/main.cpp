#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int Levenshtein(string str1, string str2) 
{
	int** d = new int*[str2.size() + 1];
	for (int i = 0; i < str2.size() + 1; i++) d[i] = new int[str1.size() + 1];
	for (int i = 0; i < str1.size() + 1; i++) d[0][i] = i;
	for (int i = 0; i < str2.size() + 1; i++) d[i][0] = i;

	for (int i = 1; i < str2.size() + 1; i++) 
	{
		for (int j = 1; j < str1.size() + 1; j++) 
		{
			int edit = str2[i - 1] == str1[j - 1] ? 0 : 1;
			d[i][j] = min(d[i - 1][j] + 1, min(d[i][j - 1] + 1, d[i - 1][j - 1] + edit));
		}
	}
	return d[str2.size()][str1.size()];
}

int main() 
{
	string input1, input2;
	while (getline(cin, input1)) 
	{
		getline(cin, input2);
		cout << Levenshtein(input1, input2) << endl;
	}
}