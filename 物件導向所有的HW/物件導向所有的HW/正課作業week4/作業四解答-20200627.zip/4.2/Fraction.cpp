#include "Fraction.h"

void Fraction::setNumerator(int nu)
{
	numerator = nu;
}

void Fraction::setDenominator(int de)
{
	denominator = de;
}

void Fraction::getDouble()
{
	double v = (double)numerator / denominator;
	if (v == (int)v)
		cout << (int)numerator / denominator << endl;
	else
		cout << fixed << setprecision(6) << (double)numerator / (double)denominator << endl;
}

void Fraction::outputReducedFraction()
{
	int a = numerator;
	int b = denominator;
	while (a != 0 && b != 0)
	{
		if (a > b)
		{
			a %= b;
			if (a == 1)
				break;
		}
		else if (b >= a)
		{
			b %= a;
			if (b == 1)
				break;
		}
	}
	int gcd = (a > b) ? a : b;
	if ((denominator / gcd) == 1)
		cout << (int)(numerator / gcd) << endl;
	else
		cout << (int)(numerator / gcd)  << "/" << (int)(denominator / gcd) << endl;
}



